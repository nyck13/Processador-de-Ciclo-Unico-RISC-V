library verilog;
use verilog.vl_types.all;
entity reg_7seg_tb is
end reg_7seg_tb;
