module XOR2x1_TB;
  // Sinais
  logic la, lb;
  logic Out;
  
  // Instanciação da porta XOR2x1
  XOR2x1 tes(.in0(la), .in1(lb), .out(Out));
  
  initial
    begin
      $dumpfile("test.vcd"); $dumpvars(1);
      $monitor("time=%3d, la=%h, lb=%h, Out = %h", $time, la, lb, Out);
      
      la = 1'b0; lb = 1'b0;
      #10;
      la = 1'b1; lb = 1'b0;
      #10;
      la = 1'b0; lb = 1'b1;
      #10;
      la = 1'b1; lb = 1'b1;
      #10;
      $display("Terminou");
    end 
endmodule