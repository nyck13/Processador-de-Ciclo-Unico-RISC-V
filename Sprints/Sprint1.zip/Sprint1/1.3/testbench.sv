module somador_TB;
  
  // Sinais 
  logic[3:0] la, lb;
  logic[3:0] Out;
  
  // Instância do somador 
  somador tes(.a(la), .b(lb), .res(Out));
  
  initial
    begin
      $dumpfile("teste.vcd"); $dumpvars(1);
      
      $monitor("time=%3d, la=%h, lb=%h, Out=%h", $time, la, lb, Out);
      
      la=4'b1111; lb=4'b0110;
      #10;
      la=4'b0011; lb=4'b0110;
      #10;
      $display("Terminou");
    end
endmodule
      