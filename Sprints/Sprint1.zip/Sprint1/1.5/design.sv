module mux2x1(input [3:0]in0, in1, input sel, output reg[3:0] out);
  always_comb
    begin
      if(sel == 0)
        out = in0;
      else
        out = in1;
    end
endmodule