module mux2x1_TB;

  logic[3:0] la, lb;
  logic S;
  logic[3:0] Out;
  
  mux2x1 tes(.in0(la), .in1(lb), .sel(S), .out(Out));
  
  initial
    begin
      $dumpfile("test.vcd"); $dumpvars(1);
      
      $monitor("time=3%d, la=%4b, lb=%4b, S=%1b, Out=%4b", $time, la, lb, S, Out);
      
      la=4'b0101; lb=4'b0001; S=1'b0;
      #10;
      la=4'b0101; lb=4'b0001; S=1'b1;
      #10;
      la=4'b0100; lb=4'b1001; S=1'b0;
      #10;
      la=4'b0100; lb=4'b1001; S=1'b1;
      #10;
      $finish();
    end
endmodule