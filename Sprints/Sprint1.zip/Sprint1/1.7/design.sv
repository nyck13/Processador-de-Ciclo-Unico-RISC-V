module somador(input[3:0] inA, inB, output[3:0] res);
  assign res = inA + inB;
endmodule 

module mux2x1(input [3:0]in0, in1, input sel, output reg[3:0] out);
  always@(*)
    begin
      if(sel == 0)
        out = in0;
      else
        out = in1;
    end
endmodule

module equivalente(input[3:0] a, b, c, input S, output[3:0] Out); 
  wire [3:0] OutMux;
  mux2x1 mux(.in0(b), .in1(c), .sel(S), .out(OutMux));
  somador soma(.inA(a), .inB(OutMux), .res(Out));
endmodule