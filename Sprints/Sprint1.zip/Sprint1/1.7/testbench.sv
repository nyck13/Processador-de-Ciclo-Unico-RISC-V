module equivalente_TB;
  logic[3:0] la, lb, lc;
  logic s;
  logic[3:0] OUT;
  
  equivalente tes(.a(la), .b(lb), .c(lc), .S(s), .Out(OUT));
  
  initial
    begin
      $dumpfile("test.vcd"); $dumpvars(1);
      
      $monitor("time=3%d, la=%4b, lb=%4b, lc=%4b, s=%1b, OUT=%4b", $time, la, lb, lc, s, OUT);
      
      la=4'b1010; lb=4'b0101; lc=4'b0001; s=1'b0;
      #10;
      la=4'b1010; lb=4'b0101; lc=4'b0001; s=1'b1;
      #10;
      $finish();
    end
endmodule