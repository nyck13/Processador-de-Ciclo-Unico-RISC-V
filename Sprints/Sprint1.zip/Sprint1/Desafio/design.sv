module ula(input[3:0] a, b, input[1:0] sel, output reg flag, output reg[3:0] res);
  always@(*) 
    begin
      flag = 1'b0;
      case(sel)
        2'b00 : res = a + b;
        2'b01 : res = a - b;
        2'b10 : res = a >> b;
        2'b11 : res = a << b;
      	default: res = 0;
      endcase

      if (sel==2'b00 && a+b>5'b01111)
        flag = 1'b1;  
    end
endmodule 