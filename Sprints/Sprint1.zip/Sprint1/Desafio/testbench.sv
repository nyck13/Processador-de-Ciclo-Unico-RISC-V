module ula_TB;
  
  // Sinais 
  logic[3:0] la, lb;
  logic[1:0] Sel;
  logic Flag;
  logic[3:0] Out;
  
  // Instância do somador 
  ula tes(.a(la), .b(lb), .flag(Flag), .sel(Sel), .res(Out));
  
  initial
    begin
      $dumpfile("teste.vcd"); $dumpvars(1);
      
      $monitor("time=%3d, la=%h, lb=%h, Flag=%h, Sel=%h, Out=%h", $time, la, lb, Flag, Sel, Out);
      
      la=4'b0011; lb=4'b0010; Sel=2'b00;
      #10;
      la=4'b0011; lb=4'b0010; Sel=2'b01;
      #10;
      la=4'b0011; lb=4'b0010; Sel=2'b10;
      #10;
      la=4'b0011; lb=4'b0010; Sel=2'b11;
      #10;
      la=4'b0001; lb=4'b1111; Sel=2'b00;
      #10;
      $display("Terminou");
    end
endmodule