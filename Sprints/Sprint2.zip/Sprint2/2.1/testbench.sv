module registrador_TB;
  reg clk, rst, en;
  reg [3:0] in;
  wire [3:0] out;
  registrador tes(.clk(clk), .rst(rst), .parallel_in(in), .parallel_out(out), .en(en));
  
  initial
    begin
      $dumpfile("test.vcd"); $dumpvars(1);
      $monitor("time=%3d, clk=%b, rst=%b, in=%b, out=%b", $time, clk, rst, en, in, out);
      
      clk = 0; rst=1; en=0; in=0'b0000;
      #1
      rst=0; en=0;
      #1
      rst=1; en=1; in=0'b0001;
      #10
      rst=1; en=1; in=0'b0010;
      #10
      rst=1; en=1; in=0'b0101;
      #10
      rst=1; en=0; in=0'b0000;
      #10
      rst=1; en=1; in=0'b0000;
      #10
      rst=1; en=1; in=0'b0000;
      #10
      rst=1; en=1; in=0'b0000;
      #10
      rst=1; en=1; in=0'b0001;
      #10
      $display("Terminou");
      $finish();
    end
  always
    begin
      #5
      clk=~clk;
    end
endmodule