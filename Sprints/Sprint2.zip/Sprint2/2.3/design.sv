// MUX 2x1
module mux2x1(input [3:0]in0, in1, input sel, output reg[3:0] out);
  always@(*)
    begin
      if(sel == 0)
        out = in0;
      else
        out = in1;
    end
endmodule

//Somador 4Bits
module somador(input[3:0] inA, inB, output[3:0] res);
  assign res = inA + inB;
endmodule 

// Registrador
module registrador(input [3:0] parallel_in, input clk, rst, en, output reg[3:0] parallel_out);

  always @(posedge clk, negedge rst)
    begin 
      if (!rst)
        parallel_out<= 4'b0000;
      else if(en)
        parallel_out<=parallel_in;
    end
endmodule

module equivalente(input[3:0] a, b, c, input s, clk, rst, en, output[3:0] Out);
  wire[3:0] outMux;
  wire[3:0] outSomador;
  mux2x1 mux(.in0(b), .in1(c), .sel(s), .out(outMux));
  somador sum(.inA(a), .inB(outMux), .res(outSomador)); 
  registrador regis(.parallel_in(outSomador), .clk(clk), .rst(rst), .en(en), .parallel_out(Out));
endmodule