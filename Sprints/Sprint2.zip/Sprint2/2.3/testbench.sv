module equivalente_TB;
  reg[3:0] la, lb, lc;
  reg clk, rst, en, S;
  wire[3:0] out;
  equivalente tes(.a(la), .b(lb), .c(lc), .s(S), .clk(clk), .rst(rst), .en(en), .Out(out));
  
  initial
    begin
      $dumpfile("test.vcd"); $dumpvars(1);
      $monitor("time=%3d, la=%4b, lb=%4b, lc=%4b, clk=%1b, rst=%1b, en=%1b, S=%1b, out=%4b", $time, la, lb, lc, clk, rst, en, S, out);
      
      clk = 0; rst=1;
      #1
      rst=0; en=0;
      #1
      la=4'b0101; lb=4'b0010; lc=4'b0001; S=0; rst=1; en=1;
      #10
      la=4'b0101; lb=4'b0010; lc=4'b0001; S=1; rst=1; en=1;
      #10
      la=4'b0101; lb=4'b0010; lc=4'b0001; S=1; rst=1; en=1;
      #10
      la=4'b0101; lb=4'b0010; lc=4'b0001; S=0; rst=1; en=0;
      #10
      la=4'b0101; lb=4'b0010; lc=4'b0001; S=0; rst=1; en=1;
      #10
      $display("Terminou");
      $finish();
    end
  always
    begin
      #5
      clk=~clk;
    end
endmodule
