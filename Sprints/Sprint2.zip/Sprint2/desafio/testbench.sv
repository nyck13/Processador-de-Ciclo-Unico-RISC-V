module equivalente_TB;
  reg[3:0] la, lb;
  reg clk, rst, en, s;
  wire[3:0] out;
  contador tes(.a(la), .b(lb), .s(s), .clk(clk), .rst(rst), .en(en), .out(out));
  
  initial
    begin
      $dumpfile("test.vcd"); $dumpvars(1);
      $monitor("time=%3d, la=%b, lb=%b, clk=%1b, rst=%1b, en=%1b, s=%1b, out=%b", $time, la, lb, clk, rst, en, s, out);
      
      la=4'b0001; lb=4'b1111; clk = 0; rst=0; en=1;
      #1
      rst=1; en=1;
      #1
      s=0; rst=1; en=1;
      #200      
      $display("Terminou");
      $finish();
    end
  always
    begin
      #5
      clk=~clk;
    end
endmodule
