module RegisterFile(input[31:0] wd3, 
                    input[4:0] wa3, ra1, ra2, 
                    input we3, clk, rst, 
                    output[31:0] rd1, rd2);
  
  reg[31:0] registrador[31:0]; // Inicializar 32 registradores de 32 bits
  integer i; // Inicializar o contador 
  
  always @(posedge clk) begin
    if(!rst) begin // Limpar os registradores na subida do clock se rst=0
      for(i = 0; i <= 31; i = i + 1)
        registrador[i] <= 32'b0;
    end
    
    else if(we3) begin // Executar caso o enable seja 1
      if(wa3 != 0) begin // Executar caso o índice do registrador seja diferente de 1
        registrador[wa3] <= wd3; // Escrever valor no registrador
      end
    end
  end
  
  assign rd1 = registrador[ra1]; // Atribuir valor na saída 1 do RegisterFile
  assign rd2 = registrador[ra2]; // Atribuir valor na saída 2 do RegisterFile
endmodule