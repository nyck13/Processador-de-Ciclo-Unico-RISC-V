module RegisterFile_TB;
  logic[31:0] wd3, rd1, rd2;
  logic[4:0] wa3, ra1, ra2;
  logic we3, clk, rst;
  integer i;
  integer erro = 0;

  RegisterFile banco(
    .wd3(wd3), 
    .wa3(wa3), 
    .ra1(ra1), 
    .ra2(ra2), 
    .we3(we3), 
    .clk(clk), 
    .rst(rst), 
    .rd1(rd1), 
    .rd2(rd2)
  );

  always #5 clk = ~clk;

  initial
    begin
      $dumpfile("test.vcd"); $dumpvars(1);
      $monitor("time=%3d, wd3=%b, wa3=%b, ra1=%b, ra2=%b, we3=%b, clk=%b, rst=%b, rd1=%b, rd2=%b, erro=%b", $time, wd3, wa3, ra1, ra2, we3, clk, rst, rd1, rd2, erro);

      erro = 0; clk = 0; rst = 1; we3 = 0; wd3 = 0; ra1 = 0; ra2 = 0; wa3 = 0;

      #10 
      rst = 0;
      #10 
      rst = 1;
      #10;

      for(i = 0; i < 32; i = i + 1) begin // Iterador para os 32 registradores
        @(negedge clk); // Descida de clock
        we3 = 1; // Enable = 1
        wa3 = i[4:0]; // Escrever o endereço como o valor do iterador
        wd3 = i; // O dado será o valor do iterador
        @(posedge clk); // Subida de clock
        @(negedge clk); // Descida de clock
        we3 = 0; // Enable = 0
        ra1 = i[4:0]; // Definir na saída ra1 o registrador de endereço i 
        #5
        if(i == 0) begin // Verificar o valor do registrador x0
          if(rd1 !== 0) begin
            erro++; // Se o registrador não for zero, o erro é somado
          end
        end
        else begin
          if(rd1 !== i) begin
            erro++; // Se o valor do registrador não condiz com i, o erro será somado 1
          end
        end
      end

      $display("Terminou");
      $finish();
    end

endmodule