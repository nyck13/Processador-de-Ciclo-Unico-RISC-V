// Registrador
module registrador (input [3:0] parallel_in, input clk, rst, en, output reg[3:0] parallel_out);

  always @(posedge clk, negedge rst)
    begin 
      if (!rst)
        parallel_out<= 4'b0000;
      else if(en)
        parallel_out<=parallel_in;
    end
endmodule