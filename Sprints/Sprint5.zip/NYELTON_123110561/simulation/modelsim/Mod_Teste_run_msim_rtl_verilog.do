transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+E:/LASD/2025.2/NYELTON_123110561 {E:/LASD/2025.2/NYELTON_123110561/mux2x1.v}
vlog -vlog01compat -work work +incdir+E:/LASD/2025.2/NYELTON_123110561 {E:/LASD/2025.2/NYELTON_123110561/ULA.v}
vlog -vlog01compat -work work +incdir+E:/LASD/2025.2/NYELTON_123110561 {E:/LASD/2025.2/NYELTON_123110561/RegisterFile.v}
vlog -vlog01compat -work work +incdir+E:/LASD/2025.2/NYELTON_123110561 {E:/LASD/2025.2/NYELTON_123110561/decodificador.v}
vlog -vlog01compat -work work +incdir+E:/LASD/2025.2/NYELTON_123110561 {E:/LASD/2025.2/NYELTON_123110561/LCD_TEST2.v}
vlog -vlog01compat -work work +incdir+E:/LASD/2025.2/NYELTON_123110561 {E:/LASD/2025.2/NYELTON_123110561/LCD_Controller.v}
vlog -sv -work work +incdir+E:/LASD/2025.2/NYELTON_123110561 {E:/LASD/2025.2/NYELTON_123110561/Mod_Teste.sv}

