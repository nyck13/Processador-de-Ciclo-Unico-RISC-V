library verilog;
use verilog.vl_types.all;
entity ULA is
    port(
        SrcA            : in     vl_logic_vector(31 downto 0);
        SrcB            : in     vl_logic_vector(31 downto 0);
        ULAControl      : in     vl_logic_vector(2 downto 0);
        ULAResult       : out    vl_logic_vector(31 downto 0);
        z               : out    vl_logic
    );
end ULA;
