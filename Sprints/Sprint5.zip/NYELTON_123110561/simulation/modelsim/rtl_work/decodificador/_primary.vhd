library verilog;
use verilog.vl_types.all;
entity decodificador is
    port(
        a               : in     vl_logic_vector(3 downto 0);
        d               : out    vl_logic_vector(0 to 6)
    );
end decodificador;
