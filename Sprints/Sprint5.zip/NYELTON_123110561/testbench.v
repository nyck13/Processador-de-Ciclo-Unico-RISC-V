module reg_7seg(
	input clk,
	input rst,
	input en,
	input [4:0]in,
	output[6:0] out
);
wire[4:0] outr;
registrador u1(.parallel_in(in),.clk(clk),.rst(rst),.en(en),.parallel_out(outr));
decodificador u2(.a(outr),.d(out));
endmodule

module reg_7seg_tb;
reg clock, reset,enable;
reg [3:0] inp;
wire[6:0] outp;

reg_7seg tes(.clk(clock),.rst(reset),.en(enable),.out(outp), .in(inp));

initial
begin
clock=1'b1; reset=1'b0; enable=1'b0; inp=4'b1000;
#10;
clock=1'b0; reset=1'b1; enable=1'b1; inp=4'b1010;
#10;
clock=1'b1; reset=1'b1; enable=1'b1; inp=4'b1111;
#10;
clock=1'b0; reset=1'b1; enable=1'b1; inp=4'b1011;
#10;
clock=1'b1; reset=1'b1; enable=1'b1; inp=4'b0111;
#10;
clock=1'b0; reset=1'b1; enable=1'b1; inp=4'b1010;
#10;
clock=1'b1; reset=1'b1; enable=1'b1; inp=4'b1111;
#10;
clock=1'b0; reset=1'b1; enable=1'b1; inp=4'b1011;
#10;
clock=1'b1; reset=1'b1; enable=1'b1; inp=4'b0111;
#10;
end
 
endmodule