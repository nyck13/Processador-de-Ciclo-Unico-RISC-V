module ControlUnit(input[6:0] Op, input[2:0] Funct3, input[6:0] Funct7, output reg[2:0] ULAControl, output reg ULASrc, RegWrite);
  
  always @(*) begin
    case(Op)
      7'b0110011: begin
        case(Funct3)
          3'b000: begin
            if(Funct7 == 7'b0000000) begin
              RegWrite =   1'b1;
              ULASrc =     1'b0;
              ULAControl = 3'b000;
            end 
            else begin
              RegWrite =   1'b1;
              ULASrc =     1'b0;
              ULAControl = 3'b001;  
            end
          end
          3'b111: begin
            RegWrite   = 1'b1;
            ULASrc     = 1'b0;
            ULAControl = 3'b010;
          end
          3'b110: begin
            RegWrite   = 1'b1;
            ULASrc     = 1'b0;
            ULAControl = 3'b011;
          end
          3'b010: begin
            RegWrite   = 1'b1;
            ULASrc     = 1'b0;
            ULAControl = 3'b101;
          end
			 default: begin
			   RegWrite   = 1'b0;
            ULASrc     = 1'b0;
            ULAControl = 3'b000;
			 end
        endcase
      end
      default: begin
        RegWrite   = 1'b1;
        ULASrc     = 1'b1;
        ULAControl = 3'b000;
      end
    endcase
  end    
endmodule
    
    