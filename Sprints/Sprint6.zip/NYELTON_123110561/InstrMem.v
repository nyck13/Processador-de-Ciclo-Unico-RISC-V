module InstrMem(input[31:0] A, output [31:0] RD);
  reg [31:0] memory [3:0];
  initial begin
    $readmemh("memory1.txt", memory);
  end
  assign RD = memory[A/4];
endmodule