module ControlUnit(
    input  [6:0] Op, 
    input  [2:0] Funct3, 
    input  [6:0] Funct7, 
    output reg [2:0] ULAControl, 
    output reg [1:0] ImmSrc, ResultSrc,
    output reg RegWrite, ULASrc, MemWrite, Branch, Jump, JumpR
);

    always @(*) begin
        case (Op)
            // R-type
            7'b0110011: begin
                case (Funct3)

                    3'b000: begin
                        if (Funct7 == 7'b0000000) begin // add
                            RegWrite   = 1'b1;
                            ULASrc     = 1'b0;
                            ULAControl = 3'b000;
                            MemWrite   = 1'b0;
                            ResultSrc  = 2'b00;
                            Branch     = 1'b0;
									 Jump       = 1'b0;
									 JumpR      = 1'b0;
                        end 
                        else begin // sub
                            RegWrite   = 1'b1;
                            ULASrc     = 1'b0;
                            ULAControl = 3'b001;  
                            MemWrite   = 1'b0;
                            ResultSrc  = 2'b00;
                            Branch     = 1'b0;
									 Jump       = 1'b0;
									 JumpR      = 1'b0;
                        end
                    end

                    3'b111: begin // and
                        RegWrite   = 1'b1;
                        ULASrc     = 1'b0;
                        ULAControl = 3'b010;
                        MemWrite   = 1'b0;
                        ResultSrc  = 2'b00;
                        Branch     = 1'b0;
								Jump       = 1'b0;
								JumpR      = 1'b0;
                    end

                    3'b110: begin // or
                        RegWrite   = 1'b1;
                        ULASrc     = 1'b0;
                        ULAControl = 3'b011;
                        MemWrite   = 1'b0;
                        ResultSrc  = 2'b00;
                        Branch     = 1'b0;
								Jump       = 1'b0;
								JumpR      = 1'b0;
                    end

                    3'b010: begin // slt
                        RegWrite   = 1'b1;
                        ULASrc     = 1'b0;
                        ULAControl = 3'b101;
                        MemWrite   = 1'b0;
                        ResultSrc  = 2'b00;
                        Branch     = 1'b0;
								Jump       = 1'b0;
								JumpR      = 1'b0;
                    end

                    default: begin
                        RegWrite   = 1'b0;
                        ImmSrc     = 2'b00;
                        ULASrc     = 1'b0;
                        ULAControl = 3'b000;
                        MemWrite   = 1'b0;
                        ResultSrc  = 2'b00;
                        Branch     = 1'b0;
								Jump       = 1'b0;
								JumpR      = 1'b0;
                    end

                endcase
            end

            // I-type (addi)
            7'b0010011: begin
                if (Funct3 == 3'b000) begin
                    RegWrite   = 1'b1;
                    ImmSrc     = 2'b00;
                    ULASrc     = 1'b1;
                    ULAControl = 3'b000;
                    MemWrite   = 1'b0;
                    ResultSrc  = 2'b00;
                    Branch     = 1'b0;
						  Jump       = 1'b0;
						  JumpR      = 1'b0;
                end
            end

				// jalr
				7'b1100111: begin
					if (Funct3 == 3'b000) begin 
					     RegWrite   = 1'b1;
                    ImmSrc     = 2'b11;
						  ULASrc     = 1'b1;
                    ULAControl = 3'b000;
                    MemWrite   = 1'b0;
						  ResultSrc  = 2'b10;
                    Branch     = 1'b0;
						  Jump       = 1'b0;
						  JumpR      = 1'b1;
					end
				end
            // lw
            7'b0000011: begin
                if (Funct3 == 3'b010) begin
                    RegWrite   = 1'b1;
                    ImmSrc     = 2'b00;
                    ULASrc     = 1'b1;
                    ULAControl = 3'b000;
                    MemWrite   = 1'b0;
                    ResultSrc  = 2'b01;
                    Branch     = 1'b0;
						  Jump       = 1'b0;
						  JumpR      = 1'b0;
                end
            end

            // sw
            7'b0100011: begin
                if (Funct3 == 3'b010) begin
                    RegWrite   = 1'b0;
                    ImmSrc     = 2'b01;
                    ULASrc     = 1'b1;
                    ULAControl = 3'b000;
                    MemWrite   = 1'b1;
                    Branch     = 1'b0;
						  Jump       = 1'b0;
						  JumpR      = 1'b0;
                end
            end
			
          	// beq
          	7'b1100011: begin
                if (Funct3 == 3'b000) begin 
                    RegWrite   = 1'b0;
                    ImmSrc     = 2'b10;
                    ULASrc     = 1'b0;
                    ULAControl = 3'b001;
                    MemWrite   = 1'b0;
                    Branch     = 1'b1;
						  Jump       = 1'b0;
						  JumpR      = 1'b0;
                end
            end
				
				// jal
				7'b1101111: begin
					RegWrite   = 1'b1;
					ImmSrc     = 2'b11;
					MemWrite   = 1'b0;
					ResultSrc  = 2'b10;
					Branch     = 1'b0;
					Jump       = 1'b1;
					JumpR      = 1'b0;
				end
        endcase
    end    

endmodule
