module DataMem(input[9:0] A, input[31:0] WD, input rst, clk, WE, output[31:0] RD);
  
  integer i;
  reg[31:0] data_memory[127:0];
  
  assign RD = (WE == 1'b0) ? data_memory[A] : 32'h00000000;
  
  always @(posedge clk) begin
    if(!rst) begin
		for(i = 0; i < 128; i = i + 1) begin
			data_memory[i] <= 32'h0;
		end
	 end
	 else begin
		 if(WE) begin
			data_memory[A] <= WD;
		 end
	 end
  end
endmodule