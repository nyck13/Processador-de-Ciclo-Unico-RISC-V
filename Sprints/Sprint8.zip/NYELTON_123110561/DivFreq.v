module DivFreq(input Clk_50MHz, output reg Clk_100Hz);

  reg[25:0] contador;
  
  initial 
    begin
      Clk_100Hz = 1'b0;
      contador = 0;
    end
  
  always @(posedge Clk_50MHz) begin
    if(contador == 250000 - 1) begin 	
      Clk_100Hz <= ~Clk_100Hz;
      contador <= 0;
    end 
    else begin
      contador <= contador + 1;
    end
  end
endmodule