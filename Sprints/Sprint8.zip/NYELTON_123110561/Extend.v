module Extend(input[20:0] in, output [31:0] out);
  assign out = {{11{in[20]}}, in};
endmodule