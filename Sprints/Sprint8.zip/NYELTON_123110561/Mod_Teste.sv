`default_nettype none //Comando para desabilitar declaração automática de wires
module Mod_Teste (
//Clocks
input CLOCK_27, CLOCK_50,
//Chaves e Botoes
input [3:0] KEY,
input [17:0] SW,
//Displays de 7 seg e LEDs
output [0:6] HEX0, HEX1, HEX2, HEX3, HEX4, HEX5, HEX6, HEX7,
output [8:0] LEDG,
output [17:0] LEDR,
//Serial
output UART_TXD,
input UART_RXD,
inout [7:0] LCD_DATA,
output LCD_ON, LCD_BLON, LCD_RW, LCD_EN, LCD_RS,
//GPIO
inout [35:0] GPIO_0, GPIO_1
);
assign GPIO_1 = 36'hzzzzzzzzz;
assign GPIO_0 = 36'hzzzzzzzzz;
assign LCD_ON = 1'b1;
assign LCD_BLON = 1'b1;
logic [7:0] w_d0x0, w_d0x1, w_d0x2, w_d0x3, w_d0x4, w_d0x5,
w_d1x0, w_d1x1, w_d1x2, w_d1x3, w_d1x4, w_d1x5;
LCD_TEST MyLCD (
.iCLK ( CLOCK_50 ),
.iRST_N ( KEY[0] ),
.d0x0(w_d0x0),.d0x1(w_d0x1),.d0x2(w_d0x2),.d0x3(w_d0x3),.d0x4(w_d0x4),.d0x5(w_d0x5),
.d1x0(w_d1x0),.d1x1(w_d1x1),.d1x2(w_d1x2),.d1x3(w_d1x3),.d1x4(w_d1x4),.d1x5(w_d1x5),
.LCD_DATA( LCD_DATA ),
.LCD_RW ( LCD_RW ),
.LCD_EN ( LCD_EN ),
.LCD_RS ( LCD_RS )
);

//---------- modifique a partir daqui --------

reg[31:0] w_PCp4;
reg[31:0] w_PC;
reg[31:0] w_Inst;
reg[2:0] w_ULAControl;
reg w_ULASrc;
reg w_RegWrite;
reg[31:0] w_rd1SrcA;
reg[31:0] w_rd2;
reg[31:0] w_Imm;
reg[31:0] w_SrcB;
reg[31:0] w_ULAResult;
reg[1:0] w_ImmSrc;
reg w_MemWrite;
reg[1:0] w_ResultSrc;
reg[31:0] w_Wd3;
reg[31:0] w_MImm;
reg[31:0] w_RData;
reg w_PCSrc;
reg w_Zero;
reg w_Branch;
reg w_Jump;
reg w_JumpR;
reg w_AndToOr;
reg clk;
reg[31:0] w_ImmPC;
reg[31:0] w_PCn;

DivFreq clock(
	.Clk_50MHz(CLOCK_50),
	.Clk_100Hz(clk)
	);

mux4x1 MuxPCSrc(
	.in0(w_PCp4),
	.in1(w_ImmPC),
	.in3(w_ULAResult),
	.out(w_PCn),
	.sel({w_JumpR, w_PCSrc})
	);

Somador somador(
	.PC(w_PC), 
	.PCp4(w_PCp4)
	);

PC pc(
	.PCin(w_PCn), 
	.PC(w_PC), 
	.rst(KEY[2]), 
	.clk(clk) // KEY[1]
	);

InstrMem instrmem(
	.A(w_PC), 
	.RD(w_Inst)
	);

ControlUnit controlunit(
	.Op(w_Inst[6:0]), 
	.Funct3(w_Inst[14:12]), 
	.Funct7(w_Inst[31:25]),
	.Branch(w_Branch),
	.ResultSrc(w_ResultSrc),
	.MemWrite(w_MemWrite),
	.ULAControl(w_ULAControl), 
	.ULASrc(w_ULASrc), 
	.ImmSrc(w_ImmSrc),
	.RegWrite(w_RegWrite)
	);

and2x1 And2(
	.in0(w_Branch),
	.in1(w_Zero),
	.out(w_AndToOr)
	);

or2x1 Or2x1(
	.in0(w_AndToOr),
	.in1(w_Jump),
	.out(w_PCSrc)
);

RegisterFile registerfile(
	.ra1(w_Inst[19:15]), 
	.ra2(w_Inst[24:20]), 
	.wa3(w_Inst[11:7]),
	.wd3(w_Wd3),
	.rst(KEY[2]),
	.clk(clk),
	.we3(w_RegWrite),
	.rd1(w_rd1SrcA),
	.rd2(w_rd2),
	.x0(w_d0x0),
	.x1(w_d0x1),
	.x2(w_d0x2),
	.x3(w_d0x3),
	.x4(w_d1x0),
	.x5(w_d1x1),
	.x6(w_d1x2),
	.x7(w_d1x3)
	);

assign w_d1x4 = w_d1x4;
	
mux4x1 MuxImmSrc(
	.in0({{9{w_Inst[31]}}, w_Inst[31:20]}),
	.in1({{9{w_Inst[31]}}, w_Inst[31:25], w_Inst[11:7]}),
	.in2({{8{w_Inst[31]}}, w_Inst[7], w_Inst[30:25], w_Inst[11:8], 1'b0}),
	.in3({w_Inst[19:12], w_Inst[20], w_Inst[30:21], 1'b0}),
	.out(w_MImm),
	.sel(w_ImmSrc)
	);

Extend extend(
	.in(w_MImm),
	.out(w_Imm)
	);

AdderImm adderimm(
	.in0(w_Imm),
	.in1(w_PC),
	.out(w_ImmPC)
	);

mux2x1 MuxULASrc(
	.in0(w_rd2), 
	.in1(w_Imm), 
	.out(w_SrcB),
	.sel(w_ULASrc)
	);

ULA ula(
	.SrcA(w_rd1SrcA), 
	.SrcB(w_SrcB), 
	.ULAControl(w_ULAControl),
	.z(w_Zero),
	.ULAResult(w_ULAResult)
	);

DataMem dataMem(
	.A(w_ULAResult),
	.WD(w_rd2),
	.rst(KEY[2]),
	.clk(clk),
	.WE(w_MemWrite), 
	.RD(w_RData)
	);

mux4x1 MuxResSrc(
	.in0(w_ULAResult),
	.in1(w_RData),
	.in2(w_PCp4),
	.out(w_Wd3),
	.sel(w_ResultSrc)
	);
	
assign w_d0x4 = w_PC;

decodificador decodificador1(.a(w_Inst[3:0]), .d(HEX0));
decodificador decodificador2(.a(w_Inst[7:4]), .d(HEX1));
decodificador decodificador3(.a(w_Inst[11:8]), .d(HEX2));
decodificador decodificador4(.a(w_Inst[15:12]), .d(HEX3));
decodificador decodificador5(.a(w_Inst[19:16]), .d(HEX4));
decodificador decodificador6(.a(w_Inst[23:20]), .d(HEX5));
decodificador decodificador7(.a(w_Inst[27:24]), .d(HEX6));
decodificador decodificador8(.a(w_Inst[31:28]), .d(HEX7));

assign LEDR[4:0] = {w_RegWrite, w_ImmSrc, w_ULASrc, w_ULAControl, w_MemWrite, w_ResultSrc};

endmodule