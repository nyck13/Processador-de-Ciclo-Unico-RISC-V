module PC(input[31:0] PCin, input rst, clk, output reg[31:0] PC);
  always @(posedge clk) begin
    if(!rst) begin
      PC <= 32'b0;
    end
    else if(clk) begin
      PC <= PCin;
    end
  end
endmodule