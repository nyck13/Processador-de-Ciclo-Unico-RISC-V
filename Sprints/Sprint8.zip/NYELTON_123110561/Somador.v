module Somador(input[31:0] PC, output[31:0] PCp4);
  assign PCp4 = PC + 3'b100;
endmodule 