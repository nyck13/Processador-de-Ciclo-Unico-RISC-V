module ULA(input[31:0] SrcA, SrcB, 
           input[2:0] ULAControl, 
           output reg[31:0] ULAResult, 
           output reg z);
  
  always@(*) begin
    case(ULAControl)
      3'b000: ULAResult = SrcA + SrcB;
      3'b001: ULAResult = SrcA + ~SrcB + 1;
      3'b010: ULAResult = SrcA & SrcB;
      3'b011: ULAResult = SrcA | SrcB;
      3'b101: 
        if(SrcA < SrcB) begin
          ULAResult = 32'b1;
        end
      	else begin
          ULAResult = 32'b0;
        end
	  default: ULAResult = 0;
    endcase
    
    if(ULAResult == 0) begin
      z = 1'b1;
    end
    else begin
      z = 1'b0;
    end
  end
endmodule
  