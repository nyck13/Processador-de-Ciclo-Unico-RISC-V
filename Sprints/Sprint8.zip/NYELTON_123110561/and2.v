module and2x1(input in0, in1, output reg out);
	always@(*) begin
		out = in0&in1;
	end
endmodule